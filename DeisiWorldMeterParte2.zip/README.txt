COMANDO CRIATIVO
Nome: GET_LEAST_POPULOUS <num-results>
Descrição: Retorna as cidades menos populosas de cada país.
Exemplo:
Rússia:aliskerovo:7
Luxemburgo:schleif:8
Panamá:el porvenir:10
Samoa:faleolo:16
Bahamas:albert town:25

https://youtu.be/WFTbjCY6p9g